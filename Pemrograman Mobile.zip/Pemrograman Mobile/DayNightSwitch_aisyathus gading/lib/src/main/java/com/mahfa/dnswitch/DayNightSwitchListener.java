package com.mahfa.dnswitch;

/**
 * Created by mohsen.falahi on 7/16/2017.
 */

public interface DayNightSwitchListener {
    void onSwitch(boolean is_night);
}
